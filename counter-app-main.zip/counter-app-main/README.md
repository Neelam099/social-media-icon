# counter-app
Here i am building a counter app using html ,css, javascript .
